async function fetchProxyConfig() {
    try {
        const response = await fetch('http://localhost:3000/proxies');
        if (!response.ok) {
            throw new Error('Falha ao obter proxies do servidor');
        }
        const proxies = await response.json();
        // Escolhe uma proxy aleatoriamente da lista
        const randomProxy = proxies[Math.floor(Math.random() * proxies.length)].trim();
        const [ip, port] = randomProxy.split(':');
        return { ip, port: parseInt(port) };
    } catch (error) {
        console.error(`Erro ao buscar configuração de proxy: ${error}`);
        return null;
    }
}

async function changeProxy() {
    const proxyConfig = await fetchProxyConfig();
    if (!proxyConfig) {
        console.log('Nenhuma configuração de proxy disponível');
        return;
    }
    const { ip, port } = proxyConfig;
    
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: ip,
                    port: port
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, () => console.log(`Proxy mudada para ${ip}:${port}`));
}

function removeProxy() {
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
        console.log('Configuração de proxy removida e revertida para o padrão do sistema.');
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "changeProxy") {
        changeProxy().then(() => {
            sendResponse({status: "completed", message: "Proxy alterada com sucesso!"});
        }).catch(error => {
            console.error("Erro ao mudar proxy:", error);
            sendResponse({status: "error", message: "Erro ao alterar proxy."});
        });
        return true; // Indica que a resposta será assíncrona.
    } else if (request.action === "removeProxy") {
        removeProxy();
        sendResponse({status: "completed", message: "Proxy removida com sucesso!"});
        // Não precisa retornar true aqui, pois removeProxy() é síncrono neste contexto.
    }
});
