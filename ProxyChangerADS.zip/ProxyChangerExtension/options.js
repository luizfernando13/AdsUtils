document.addEventListener('DOMContentLoaded', showCurrentIp);

document.getElementById('changeProxy').addEventListener('click', () => {
    const changeProxyBtn = document.getElementById('changeProxy');
    const icon = changeProxyBtn.querySelector('i');
    icon.classList.add('button-loading');
    
    chrome.runtime.sendMessage({ action: "changeProxy" }, () => {
        // Assume que o background script responderá quando a proxy for alterada.
        // Atraso artificial para visualização da animação; ajuste conforme necessário.
        setTimeout(() => {
            icon.classList.remove('button-loading');
            showCurrentIp();
            showFeedbackMessage('Proxy alterada com sucesso!');
        }, 100); // Ajuste conforme necessário.
    });
});

document.getElementById('removeProxy').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: "removeProxy" }, () => {
        showCurrentIp();
        showFeedbackMessage('Proxy removida com sucesso!');
    });
});

function showCurrentIp() {
    fetch('https://api.ipify.org?format=json')
        .then(response => response.json())
        .then(data => {
            document.getElementById('ip').innerText = `IP Atual: ${data.ip}`;
        })
        .catch(error => {
            console.error('Erro ao buscar o IP atual:', error);
            document.getElementById('ip').innerText = 'IP Atual: Erro ao carregar';
        });
}

function showFeedbackMessage(message) {
    const feedback = document.createElement('div');
    feedback.classList.add('feedback-message');
    feedback.innerText = message;
    document.body.appendChild(feedback);

    // Remove a mensagem depois de alguns segundos
    setTimeout(() => {
        feedback.style.opacity = '0';
        setTimeout(() => feedback.remove(), 500); // Ajusta conforme a duração da transição de opacidade no CSS
    }, 3000);
}
